package com.example.datingapp.Classes

data class ChatMessage(
    val senderId: Int,
    val receiverId: Int,
    val message: String
)
