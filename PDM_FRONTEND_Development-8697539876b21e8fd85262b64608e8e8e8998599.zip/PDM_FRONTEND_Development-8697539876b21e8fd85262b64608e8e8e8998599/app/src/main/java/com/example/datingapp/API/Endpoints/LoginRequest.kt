package com.example.datingapp.API.Endpoints

data class LoginRequest(
    val email: String,
    val password: String
)
