package com.example.datingapp.API.Endpoints

data class RegisterResponse(
    val success: Boolean,
    val message: String
)
