package com.example.datingapp.API.Endpoints

data class GenericResponse(
    val success: Boolean,
    val message: String
)
