package com.example.datingapp.API.Endpoints

data class GetProfileRequest(
    val isFull: Boolean,
    val morePhotos: Boolean,
)

