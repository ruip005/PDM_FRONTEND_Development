package com.example.datingapp.API.Endpoints

class SwipeResponse (
    val MessagesList: List<Message>
)