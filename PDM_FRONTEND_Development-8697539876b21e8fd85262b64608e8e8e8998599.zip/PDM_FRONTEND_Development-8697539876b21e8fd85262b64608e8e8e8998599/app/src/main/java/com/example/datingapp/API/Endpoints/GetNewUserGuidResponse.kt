package com.example.datingapp.API.Endpoints

class GetNewUserGuidResponse(
    val success: Boolean,
    val message: String,
    val newGuid: String
)