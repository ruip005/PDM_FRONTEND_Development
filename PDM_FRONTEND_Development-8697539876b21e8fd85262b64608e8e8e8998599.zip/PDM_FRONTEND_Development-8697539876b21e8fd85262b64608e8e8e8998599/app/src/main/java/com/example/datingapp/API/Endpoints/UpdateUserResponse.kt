package com.example.datingapp.API.Endpoints

data class UpdateUserResponse(
    val success: Boolean,
    val message: String
)
